Minimal Django blog app (for submission)

Files included:
- blogsite/settings.py (excerpt)
- blogsite/urls.py
- blog/models.py
- blog/views.py
- blog/forms.py
- blog/urls.py
- blog/admin.py
- blog/templates/blog/post_list.html
- blog/templates/blog/post_create.html

To run this locally:
1. Create a Django project (or place the 'blog' app into an existing project).
2. Add 'blog' to INSTALLED_APPS.
3. Ensure templates discovery is enabled (default).
4. Run migrations and start the server.

This zip also includes three PNG "screenshots":
- screenshot_blog.png  (simulated render of the post list HTML)
- screenshot_views_py.png  (screenshot of views.py)
- screenshot_post_list_html.png  (screenshot of the HTML template)

The screenshots are programmatically generated images (text render).
